flag{file_payload_zip_text}
